import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class YyszxPlugin extends StatefulWidget {
  const YyszxPlugin({super.key});

  @override
  State<YyszxPlugin> createState() => _YyszxPluginState();
}

class _YyszxPluginState extends State<YyszxPlugin> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  
  bool _isWindowVisible = false;
  bool _isExpanded = false;
  
  // 悬浮球位置
  Offset _ballPosition = const Offset(100, 100);
  
  // 窗口位置和大小
  Offset _windowPosition = const Offset(200, 200);
  Size _windowSize = const Size(400, 500);
  
  // 拖拽状态
  bool _isDraggingBall = false;
  bool _isDraggingWindow = false;
  bool _isResizingWindow = false;
  
  Offset _dragStartOffset = Offset.zero;
  Offset _windowStartPos = Offset.zero;
  Size _windowStartSize = const Size(400, 500);
  
  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _loadSettings();
  }
  
  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }
  
  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _ballPosition = Offset(
        prefs.getDouble('ball_x') ?? 100,
        prefs.getDouble('ball_y') ?? 100,
      );
      _windowPosition = Offset(
        prefs.getDouble('window_x') ?? 200,
        prefs.getDouble('window_y') ?? 200,
      );
      _windowSize = Size(
        prefs.getDouble('window_w') ?? 400,
        prefs.getDouble('window_h') ?? 500,
      );
    });
  }
  
  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('ball_x', _ballPosition.dx);
    await prefs.setDouble('ball_y', _ballPosition.dy);
    await prefs.setDouble('window_x', _windowPosition.dx);
    await prefs.setDouble('window_y', _windowPosition.dy);
    await prefs.setDouble('window_w', _windowSize.width);
    await prefs.setDouble('window_h', _windowSize.height);
  }
  
  void _toggleWindow() {
    setState(() {
      _isWindowVisible = !_isWindowVisible;
      if (_isWindowVisible) {
        _fadeController.forward();
      } else {
        _fadeController.reverse();
      }
    });
  }
  
  void _toggleExpand() {
    setState(() {
      _isExpanded = !_isExpanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // 悬浮球
        Positioned(
          left: _ballPosition.dx,
          top: _ballPosition.dy,
          child: GestureDetector(
            onPanStart: (details) {
              setState(() {
                _isDraggingBall = true;
                _dragStartOffset = details.globalPosition - _ballPosition;
              });
            },
            onPanUpdate: (details) {
              if (_isDraggingBall) {
                setState(() {
                  _ballPosition = details.globalPosition - _dragStartOffset;
                });
              }
            },
            onPanEnd: (details) {
              setState(() {
                _isDraggingBall = false;
              });
              _saveSettings();
            },
            onTap: _toggleWindow,
            child: Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    Colors.blue.withOpacity(0.8),
                    Colors.purple.withOpacity(0.8),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: const Icon(
                Icons.apps,
                color: Colors.white,
                size: 28,
              ),
            ),
          ),
        ),
        
        // 毛玻璃窗口
        if (_isWindowVisible)
          Positioned(
            left: _windowPosition.dx,
            top: _windowPosition.dy,
            child: GestureDetector(
              onPanStart: (details) {
                setState(() {
                  if (details.globalPosition.dx < _windowPosition.dx + _windowSize.width - 20) {
                    _isDraggingWindow = true;
                    _windowStartPos = _windowPosition;
                    _dragStartOffset = details.globalPosition;
                  } else {
                    _isResizingWindow = true;
                    _windowStartSize = _windowSize;
                    _dragStartOffset = details.globalPosition;
                  }
                });
              },
              onPanUpdate: (details) {
                if (_isDraggingWindow) {
                  setState(() {
                    _windowPosition = _windowStartPos + (details.globalPosition - _dragStartOffset);
                  });
                } else if (_isResizingWindow) {
                  final delta = details.globalPosition - _dragStartOffset;
                  setState(() {
                    _windowSize = Size(
                      (_windowStartSize.width + delta.dx).clamp(300, double.infinity),
                      (_windowStartSize.height + delta.dy).clamp(300, double.infinity),
                    );
                  });
                }
              },
              onPanEnd: (details) {
                setState(() {
                  _isDraggingWindow = false;
                  _isResizingWindow = false;
                });
                _saveSettings();
              },
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: Container(
                  width: _windowSize.width,
                  height: _windowSize.height,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.black.withOpacity(0.4),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 20,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withOpacity(0.1),
                              Colors.white.withOpacity(0.05),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                        child: Column(
                          children: [
                            // 标题栏
                            Container(
                              height: 50,
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.white.withOpacity(0.1),
                                  ),
                                ),
                              ),
                              child: Row(
                                children: [
                                  const Text(
                                    'yyszx',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const Spacer(),
                                  GestureDetector(
                                    onTap: _toggleExpand,
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      child: Icon(
                                        _isExpanded ? Icons.expand_less : Icons.expand_more,
                                        color: Colors.white.withOpacity(0.8),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  GestureDetector(
                                    onTap: _toggleWindow,
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      child: Icon(
                                        Icons.close,
                                        color: Colors.white.withOpacity(0.8),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // 内容区域（空壳子）
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.white.withOpacity(0.05),
                                      Colors.black.withOpacity(0.1),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            // 调整大小提示
                            Positioned(
                              right: 0,
                              bottom: 0,
                              child: Container(
                                width: 20,
                                height: 20,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.1),
                                  borderRadius: const BorderRadius.only(
                                    topRight: Radius.circular(15),
                                  ),
                                ),
                                child: Icon(
                                  Icons.arrow_outward,
                                  size: 12,
                                  color: Colors.white.withOpacity(0.6),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
