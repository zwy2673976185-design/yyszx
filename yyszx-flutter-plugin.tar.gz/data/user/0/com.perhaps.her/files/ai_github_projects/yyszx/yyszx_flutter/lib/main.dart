import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'yyszx_plugin.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'yyszx',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.transparent,
      ),
      home: const Scaffold(
        body: YyszxPlugin(),
      ),
    );
  }
}
